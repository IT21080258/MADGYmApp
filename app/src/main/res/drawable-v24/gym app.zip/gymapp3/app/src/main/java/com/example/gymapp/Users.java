package com.example.gymapp;

public class Users {

    public String fullname;
    public String email;
    public String phonenumber;


    public Users() {

    }

    public Users(String fullname, String email, String phonenumber) {
        this.fullname= fullname;
        this.email = email;
        this.phonenumber=phonenumber;
    }
}
